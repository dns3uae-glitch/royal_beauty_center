/* ============================================================
   Royal Beauty Center - menu page (bilingual, installable)
   ============================================================ */
(function () {
  'use strict';
  var R = window.RBC, C = R.C, S = C.settings;
  var $ = function (id) { return document.getElementById(id); };
  var esc = R.esc;

  var ic = {
    wa: '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 2a10 10 0 0 0-8.6 15.1L2 22l5-1.3A10 10 0 1 0 12 2zm4.5 12.1c-.2-.1-1.5-.7-1.7-.8-.2-.1-.4-.1-.6.1l-.8 1c-.1.2-.3.2-.5.1a6.7 6.7 0 0 1-3.3-2.9c-.3-.4.2-.4.7-1.4.1-.2 0-.3 0-.4l-.8-1.8c-.2-.5-.4-.4-.6-.4h-.5a1 1 0 0 0-.7.3 3 3 0 0 0-.9 2.2 5.2 5.2 0 0 0 1.1 2.7 11.8 11.8 0 0 0 4.5 4c1.7.7 2.3.8 3.2.6a2.7 2.7 0 0 0 1.8-1.3 2.2 2.2 0 0 0 .2-1.3c-.1-.1-.3-.2-.5-.3z"/></svg>',
    ig: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="18" height="18" rx="5"/><circle cx="12" cy="12" r="4"/><circle cx="17.5" cy="6.5" r="1" fill="currentColor"/></svg>',
    ph: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"><path d="M5 3h4l2 5-2.5 1.5a11 11 0 0 0 6 6L16 13l5 2v4a2 2 0 0 1-2 2A17 17 0 0 1 3 5a2 2 0 0 1 2-2z"/></svg>',
    em: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="m3 7 9 6 9-6"/></svg>'
  };

  function contactHTML() {
    var h = '', wa = R.waLink(null);
    if (wa) h += '<a class="ct ct-wa" href="' + wa + '" target="_blank" rel="noopener">' + ic.wa + '<span>' + esc(R.T('whatsapp')) + '</span></a>';
    if (S.phone) h += '<a class="ct" href="tel:' + esc(S.phone) + '">' + ic.ph + '<span dir="ltr">' + esc(S.phone) + '</span></a>';
    if (S.instagram) h += '<a class="ct" href="https://instagram.com/' + esc(S.instagram) + '" target="_blank" rel="noopener">' + ic.ig + '<span dir="ltr">@' + esc(S.instagram) + '</span></a>';
    if (S.email) h += '<a class="ct" href="mailto:' + esc(S.email) + '">' + ic.em + '<span dir="ltr">' + esc(S.email) + '</span></a>';
    return h;
  }

  function cardHTML(s, i) {
    return '<button class="card" type="button" data-id="' + esc(s.id) + '" style="--i:' + (i % 8) + '" aria-label="' + esc(R.L(s.name)) + '">' +
      '<div class="face" id="face-' + esc(s.id) + '"><div class="face-in">' +
      '<div class="face-pic"><img src="' + esc(R.asset(s.image)) + '" data-key="' + esc(s.image) + '" alt="" draggable="false" loading="lazy"><span class="face-shine"></span></div>' +
      '<span class="face-num">' + (i + 1) + '</span>' +
      '<span class="badge3d">3D</span>' +
      '<span class="face-text"><span class="face-name">' + esc(R.L(s.name)) + '</span>' +
      '<span class="face-price"><b dir="ltr">' + R.priceShort(s) + '</b> ' + esc(R.L(S.currency)) + '</span></span>' +
      '<span class="face-frame"></span>' +
      '</div></div></button>';
  }

  /* single-file build: reuse pictures already inside the page instead of a second embedded copy */
  (function harvest() {
    var m = window.RBC_EMBED || {};
    document.querySelectorAll('img[data-key]').forEach(function (i) {
      var k = i.getAttribute('data-key'), v = i.getAttribute('src') || '';
      if (k && !m[k] && v.indexOf('data:') === 0) m[k] = v;
    });
    [['data-logo', S.logo], ['data-crown', S.crown]].forEach(function (a) {
      var i = document.querySelector('img[' + a[0] + ']'), v = i && i.getAttribute('src') || '';
      if (i && a[1] && !m[a[1]] && v.indexOf('data:') === 0) m[a[1]] = v;
    });
    window.RBC_EMBED = m;
  })();

  function render() {
    var html = document.documentElement;
    html.lang = R.lang; html.dir = R.dir();
    document.title = R.L(S.name) + ' | ' + R.other(S.name);
    document.querySelectorAll('[data-logo]').forEach(function (n) { n.src = R.asset(S.logo); });
    document.querySelectorAll('[data-crown]').forEach(function (n) { n.src = R.asset(S.crown); });
    document.querySelectorAll('[data-salon]').forEach(function (n) { n.textContent = R.L(S.name); });
    document.querySelectorAll('[data-t]').forEach(function (n) { var t = R.T(n.getAttribute('data-t')); if (t) n.textContent = t; });
    document.querySelectorAll('[data-t-aria]').forEach(function (n) { n.setAttribute('aria-label', R.T(n.getAttribute('data-t-aria'))); });
    $('tagline').textContent = R.L(S.tagline);
    $('q').placeholder = R.T('search');
    $('lang').textContent = R.T('langSwitch');
    $('lang').setAttribute('lang', R.lang === 'ar' ? 'en' : 'ar');
    $('contact').innerHTML = contactHTML();
    $('contact2').innerHTML = contactHTML();

    var vis = R.visible();
    var cats = C.categories.filter(function (c) { return vis.some(function (s) { return s.cat === c.id; }); });
    $('tabs-in').innerHTML = cats.map(function (c, i) {
      return '<a class="tab' + (i === 0 ? ' on' : '') + '" href="#sec-' + esc(c.id) + '" data-cat="' + esc(c.id) + '">' + esc(R.L(c.name)) + '</a>';
    }).join('');
    $('menu').innerHTML = cats.map(function (c) {
      var list = vis.filter(function (s) { return s.cat === c.id; });
      return '<section class="sec" id="sec-' + esc(c.id) + '" data-cat="' + esc(c.id) + '">' +
        '<header class="sec-head"><h2 class="sec-title">' + esc(R.L(c.name)) + '</h2>' +
        '<span class="sec-sub" lang="' + (R.lang === 'ar' ? 'en' : 'ar') + '">' + esc(R.other(c.name)) + '</span>' +
        '<span class="sec-count">' + esc(R.T('count', { n: list.length })) + '</span></header>' +
        '<div class="grid">' + list.map(cardHTML).join('') + '</div></section>';
    }).join('');
    observeSections();
    if ($('q').value) filter();
  }

  /* ---------- tabs ---------- */
  var io = null;
  function setActive(id) {
    var tabs = $('tabs-in');
    tabs.querySelectorAll('.tab').forEach(function (t) {
      var on = t.getAttribute('data-cat') === id;
      t.classList.toggle('on', on);
      if (on && tabs.scrollWidth > tabs.clientWidth) {
        var l = t.offsetLeft - (tabs.clientWidth - t.offsetWidth) / 2;
        tabs.scrollTo({ left: l, behavior: 'smooth' });
      }
    });
  }
  function observeSections() {
    if (!('IntersectionObserver' in window)) return;
    if (io) io.disconnect();
    io = new IntersectionObserver(function (es) {
      es.forEach(function (e) { if (e.isIntersecting) setActive(e.target.getAttribute('data-cat')); });
    }, { rootMargin: '-45% 0px -50% 0px' });
    document.querySelectorAll('.sec').forEach(function (s) { io.observe(s); });
  }
  $('tabs-in').addEventListener('click', function (e) {
    var t = e.target.closest('.tab'); if (!t) return;
    e.preventDefault();
    var sec = $('sec-' + t.getAttribute('data-cat'));
    var y = sec.getBoundingClientRect().top + window.pageYOffset - $('tabs').offsetHeight - 8;
    window.scrollTo({ top: y, behavior: 'smooth' });
  });

  /* ---------- search (both languages) ---------- */
  function norm(t) { return String(t).toLowerCase().replace(/[أإآ]/g, 'ا').replace(/ة/g, 'ه').replace(/ى/g, 'ي').replace(/[ً-ْ]/g, ''); }
  function filter() {
    var v = norm($('q').value.trim()), any = false;
    document.querySelectorAll('.sec').forEach(function (sec) {
      var n = 0;
      sec.querySelectorAll('.card').forEach(function (card) {
        var s = C.services.filter(function (x) { return x.id === card.getAttribute('data-id'); })[0];
        var hay = norm([R.L(s.name, 'ar'), R.L(s.name, 'en'), R.L(s.desc, 'ar'), R.L(s.desc, 'en')].join(' '));
        var hit = !v || hay.indexOf(v) > -1;
        card.hidden = !hit; if (hit) n++;
      });
      sec.hidden = n === 0; if (n) any = true;
    });
    $('empty').hidden = any;
  }
  $('q').addEventListener('input', filter);

  /* ---------- language ---------- */
  $('lang').addEventListener('click', function () {
    var top = window.pageYOffset;
    R.setLang(R.lang === 'ar' ? 'en' : 'ar');
    render();
    window.scrollTo(0, top);
  });

  /* ---------- hover tilt ---------- */
  var menu = $('menu');
  if (window.matchMedia && window.matchMedia('(hover: hover) and (pointer: fine)').matches) {
    menu.addEventListener('pointermove', function (e) {
      var card = e.target.closest('.card'); if (!card) return;
      var r = card.getBoundingClientRect();
      var x = (e.clientX - r.left) / r.width - 0.5, y = (e.clientY - r.top) / r.height - 0.5;
      card.classList.add('tilting');
      card.style.setProperty('--ry', (x * 12).toFixed(2) + 'deg');
      card.style.setProperty('--rx', (-y * 12).toFixed(2) + 'deg');
    });
    menu.addEventListener('pointerout', function (e) {
      var card = e.target.closest('.card'); if (!card || card.contains(e.relatedTarget)) return;
      card.classList.remove('tilting');
      card.style.setProperty('--ry', '0deg'); card.style.setProperty('--rx', '0deg');
    });
  }

  /* ---------- 3D viewer ---------- */
  var viewer = null;
  try { viewer = new window.RBCViewer($('viewer')); } catch (err) { viewer = null; }
  function getFace(id) { return $('face-' + id); }
  menu.addEventListener('click', function (e) {
    var card = e.target.closest('.card'); if (!card || !viewer) return;
    card.classList.remove('tilting');
    card.style.transition = 'none';
    card.style.setProperty('--ry', '0deg'); card.style.setProperty('--rx', '0deg');
    card.style.animation = 'none';
    void card.offsetWidth;
    card.style.transition = '';
    var id = card.getAttribute('data-id');
    var svc = C.services.filter(function (s) { return s.id === id; })[0];
    var list = R.visible().filter(function (s) {
      var f = getFace(s.id);
      return s.cat === svc.cat && f && !f.closest('.card').hidden;
    });
    var idx = 0;
    list.forEach(function (s, i) { if (s.id === id) idx = i; });
    viewer.open(list, idx, getFace);
  });

  /* ---------- installable app (PWA) ---------- */
  var deferred = null, installBtn = $('install');
  var isIOS = /iphone|ipad|ipod/i.test(navigator.userAgent) || (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);
  var standalone = (window.matchMedia && window.matchMedia('(display-mode: standalone)').matches) || navigator.standalone === true;
  window.addEventListener('beforeinstallprompt', function (e) { e.preventDefault(); if (window.RBC_NATIVE) return; deferred = e; installBtn.hidden = false; });
  if (window.RBC_NATIVE) standalone = true;
  if (isIOS && !standalone && /^https?:/.test(location.protocol)) installBtn.hidden = false;
  installBtn.addEventListener('click', function () {
    if (deferred) {
      deferred.prompt();
      deferred.userChoice.then(function () { deferred = null; installBtn.hidden = true; });
    } else {
      var tip = $('ios-tip'); tip.hidden = false;
      setTimeout(function () { tip.hidden = true; }, 7000);
    }
  });
  window.addEventListener('appinstalled', function () { installBtn.hidden = true; });
  if (!window.RBC_NATIVE && 'serviceWorker' in navigator && /^https?:/.test(location.protocol)) {
    window.addEventListener('load', function () { navigator.serviceWorker.register('sw.js').catch(function () {}); });
  }

  render();

  /* store app: refresh prices from the salon website (silent when offline) */
  if (R.checkRemote) {
    var refresh = function () {
      R.checkRemote(function () {
        if (document.getElementById('viewer').hidden) location.reload();
        else window.RBC_PENDING_RELOAD = true;
      });
    };
    refresh();
    document.addEventListener('visibilitychange', function () { if (!document.hidden) refresh(); });
  }
})();
